import request from '@/config/axios'

// 外部物流商登录信息 VO
export interface LoginInfoOuterVO {
  userName: string // 物流商分配账号
  password: string // 物流商秘钥
  logisticsCompanyId: number // 物流服务商ID
  logisticsNetworkId: number // 物流网点ID
  callTyp: string // 接口调用方式1：web连接器；2：接口
  status: string // 有效标志1：有效；0：无效
}

// 外部物流商登录信息 API
export const LoginInfoOuterApi = {
  // 查询外部物流商登录信息分页
  getLoginInfoOuterPage: async (params: any) => {
    return await request.get({ url: `/system/login-info-outer/page`, params })
  },

  // 查询外部物流商登录信息详情
  getLoginInfoOuter: async (id: number) => {
    return await request.get({ url: `/system/login-info-outer/get?id=` + id })
  },

  // 新增外部物流商登录信息
  createLoginInfoOuter: async (data: LoginInfoOuterVO) => {
    return await request.post({ url: `/system/login-info-outer/create`, data })
  },

  // 修改外部物流商登录信息
  updateLoginInfoOuter: async (data: LoginInfoOuterVO) => {
    return await request.put({ url: `/system/login-info-outer/update`, data })
  },

  // 删除外部物流商登录信息
  deleteLoginInfoOuter: async (id: number) => {
    return await request.delete({ url: `/system/login-info-outer/delete?id=` + id })
  },

  // 导出外部物流商登录信息 Excel
  exportLoginInfoOuter: async (params) => {
    return await request.download({ url: `/system/login-info-outer/export-excel`, params })
  },
}