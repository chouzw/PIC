package com.baidatms.module.system.service.logininfoouter;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import jakarta.annotation.Resource;

import com.baidatms.framework.test.core.ut.BaseDbUnitTest;

import com.baidatms.module.system.controller.admin.logininfoouter.vo.*;
import com.baidatms.module.system.dal.dataobject.logininfoouter.LoginInfoOuterDO;
import com.baidatms.module.system.dal.mysql.logininfoouter.LoginInfoOuterMapper;
import com.baidatms.framework.common.pojo.PageResult;

import jakarta.annotation.Resource;
import org.springframework.context.annotation.Import;
import java.util.*;
import java.time.LocalDateTime;

import static cn.hutool.core.util.RandomUtil.*;
import static com.baidatms.module.system.enums.ErrorCodeConstants.*;
import static com.baidatms.framework.test.core.util.AssertUtils.*;
import static com.baidatms.framework.test.core.util.RandomUtils.*;
import static com.baidatms.framework.common.util.date.LocalDateTimeUtils.*;
import static com.baidatms.framework.common.util.object.ObjectUtils.*;
import static com.baidatms.framework.common.util.date.DateUtils.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * {@link LoginInfoOuterServiceImpl} 的单元测试类
 *
 * @author nodal
 */
@Import(LoginInfoOuterServiceImpl.class)
public class LoginInfoOuterServiceImplTest extends BaseDbUnitTest {

    @Resource
    private LoginInfoOuterServiceImpl loginInfoOuterService;

    @Resource
    private LoginInfoOuterMapper loginInfoOuterMapper;

    @Test
    public void testCreateLoginInfoOuter_success() {
        // 准备参数
        LoginInfoOuterSaveReqVO createReqVO = randomPojo(LoginInfoOuterSaveReqVO.class).setId(null);

        // 调用
        Long loginInfoOuterId = loginInfoOuterService.createLoginInfoOuter(createReqVO);
        // 断言
        assertNotNull(loginInfoOuterId);
        // 校验记录的属性是否正确
        LoginInfoOuterDO loginInfoOuter = loginInfoOuterMapper.selectById(loginInfoOuterId);
        assertPojoEquals(createReqVO, loginInfoOuter, "id");
    }

    @Test
    public void testUpdateLoginInfoOuter_success() {
        // mock 数据
        LoginInfoOuterDO dbLoginInfoOuter = randomPojo(LoginInfoOuterDO.class);
        loginInfoOuterMapper.insert(dbLoginInfoOuter);// @Sql: 先插入出一条存在的数据
        // 准备参数
        LoginInfoOuterSaveReqVO updateReqVO = randomPojo(LoginInfoOuterSaveReqVO.class, o -> {
            o.setId(dbLoginInfoOuter.getId()); // 设置更新的 ID
        });

        // 调用
        loginInfoOuterService.updateLoginInfoOuter(updateReqVO);
        // 校验是否更新正确
        LoginInfoOuterDO loginInfoOuter = loginInfoOuterMapper.selectById(updateReqVO.getId()); // 获取最新的
        assertPojoEquals(updateReqVO, loginInfoOuter);
    }

    @Test
    public void testUpdateLoginInfoOuter_notExists() {
        // 准备参数
        LoginInfoOuterSaveReqVO updateReqVO = randomPojo(LoginInfoOuterSaveReqVO.class);

        // 调用, 并断言异常
        assertServiceException(() -> loginInfoOuterService.updateLoginInfoOuter(updateReqVO), LOGIN_INFO_OUTER_NOT_EXISTS);
    }

    @Test
    public void testDeleteLoginInfoOuter_success() {
        // mock 数据
        LoginInfoOuterDO dbLoginInfoOuter = randomPojo(LoginInfoOuterDO.class);
        loginInfoOuterMapper.insert(dbLoginInfoOuter);// @Sql: 先插入出一条存在的数据
        // 准备参数
        Long id = dbLoginInfoOuter.getId();

        // 调用
        loginInfoOuterService.deleteLoginInfoOuter(id);
       // 校验数据不存在了
       assertNull(loginInfoOuterMapper.selectById(id));
    }

    @Test
    public void testDeleteLoginInfoOuter_notExists() {
        // 准备参数
        Long id = randomLongId();

        // 调用, 并断言异常
        assertServiceException(() -> loginInfoOuterService.deleteLoginInfoOuter(id), LOGIN_INFO_OUTER_NOT_EXISTS);
    }

    @Test
    @Disabled  // TODO 请修改 null 为需要的值，然后删除 @Disabled 注解
    public void testGetLoginInfoOuterPage() {
       // mock 数据
       LoginInfoOuterDO dbLoginInfoOuter = randomPojo(LoginInfoOuterDO.class, o -> { // 等会查询到
           o.setUserName(null);
           o.setLogisticsCompanyId(null);
           o.setLogisticsNetworkId(null);
           o.setCreateTime(null);
           o.setStatus(null);
       });
       loginInfoOuterMapper.insert(dbLoginInfoOuter);
       // 测试 userName 不匹配
       loginInfoOuterMapper.insert(cloneIgnoreId(dbLoginInfoOuter, o -> o.setUserName(null)));
       // 测试 logisticsCompanyId 不匹配
       loginInfoOuterMapper.insert(cloneIgnoreId(dbLoginInfoOuter, o -> o.setLogisticsCompanyId(null)));
       // 测试 logisticsNetworkId 不匹配
       loginInfoOuterMapper.insert(cloneIgnoreId(dbLoginInfoOuter, o -> o.setLogisticsNetworkId(null)));
       // 测试 createTime 不匹配
       loginInfoOuterMapper.insert(cloneIgnoreId(dbLoginInfoOuter, o -> o.setCreateTime(null)));
       // 测试 status 不匹配
       loginInfoOuterMapper.insert(cloneIgnoreId(dbLoginInfoOuter, o -> o.setStatus(null)));
       // 准备参数
       LoginInfoOuterPageReqVO reqVO = new LoginInfoOuterPageReqVO();
       reqVO.setUserName(null);
       reqVO.setLogisticsCompanyId(null);
       reqVO.setLogisticsNetworkId(null);
       reqVO.setCreateTime(buildBetweenTime(2023, 2, 1, 2023, 2, 28));
       reqVO.setStatus(null);

       // 调用
       PageResult<LoginInfoOuterDO> pageResult = loginInfoOuterService.getLoginInfoOuterPage(reqVO);
       // 断言
       assertEquals(1, pageResult.getTotal());
       assertEquals(1, pageResult.getList().size());
       assertPojoEquals(dbLoginInfoOuter, pageResult.getList().get(0));
    }

}