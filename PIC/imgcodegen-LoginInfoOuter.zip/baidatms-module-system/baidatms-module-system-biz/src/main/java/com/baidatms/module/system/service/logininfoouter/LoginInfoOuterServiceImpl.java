package com.baidatms.module.system.service.logininfoouter;

import org.springframework.stereotype.Service;
import jakarta.annotation.Resource;
import org.springframework.validation.annotation.Validated;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import com.baidatms.module.system.controller.admin.logininfoouter.vo.*;
import com.baidatms.module.system.dal.dataobject.logininfoouter.LoginInfoOuterDO;
import com.baidatms.framework.common.pojo.PageResult;
import com.baidatms.framework.common.pojo.PageParam;
import com.baidatms.framework.common.util.object.BeanUtils;

import com.baidatms.module.system.dal.mysql.logininfoouter.LoginInfoOuterMapper;

import static com.baidatms.framework.common.exception.util.ServiceExceptionUtil.exception;
import static com.baidatms.module.system.enums.ErrorCodeConstants.*;

/**
 * 外部物流商登录信息 Service 实现类
 *
 * @author nodal
 */
@Service
@Validated
public class LoginInfoOuterServiceImpl implements LoginInfoOuterService {

    @Resource
    private LoginInfoOuterMapper loginInfoOuterMapper;

    @Override
    public Long createLoginInfoOuter(LoginInfoOuterSaveReqVO createReqVO) {
        // 插入
        LoginInfoOuterDO loginInfoOuter = BeanUtils.toBean(createReqVO, LoginInfoOuterDO.class);
        loginInfoOuterMapper.insert(loginInfoOuter);
        // 返回
        return loginInfoOuter.getId();
    }

    @Override
    public void updateLoginInfoOuter(LoginInfoOuterSaveReqVO updateReqVO) {
        // 校验存在
        validateLoginInfoOuterExists(updateReqVO.getId());
        // 更新
        LoginInfoOuterDO updateObj = BeanUtils.toBean(updateReqVO, LoginInfoOuterDO.class);
        loginInfoOuterMapper.updateById(updateObj);
    }

    @Override
    public void deleteLoginInfoOuter(Long id) {
        // 校验存在
        validateLoginInfoOuterExists(id);
        // 删除
        loginInfoOuterMapper.deleteById(id);
    }

    private void validateLoginInfoOuterExists(Long id) {
        if (loginInfoOuterMapper.selectById(id) == null) {
            throw exception(LOGIN_INFO_OUTER_NOT_EXISTS);
        }
    }

    @Override
    public LoginInfoOuterDO getLoginInfoOuter(Long id) {
        return loginInfoOuterMapper.selectById(id);
    }

    @Override
    public PageResult<LoginInfoOuterDO> getLoginInfoOuterPage(LoginInfoOuterPageReqVO pageReqVO) {
        return loginInfoOuterMapper.selectPage(pageReqVO);
    }

}