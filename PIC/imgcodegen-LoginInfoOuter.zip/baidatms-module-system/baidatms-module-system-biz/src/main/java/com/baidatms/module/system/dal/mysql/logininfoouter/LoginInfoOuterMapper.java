package com.baidatms.module.system.dal.mysql.logininfoouter;

import java.util.*;

import com.baidatms.framework.common.pojo.PageResult;
import com.baidatms.framework.mybatis.core.query.LambdaQueryWrapperX;
import com.baidatms.framework.mybatis.core.mapper.BaseMapperX;
import com.baidatms.module.system.dal.dataobject.logininfoouter.LoginInfoOuterDO;
import org.apache.ibatis.annotations.Mapper;
import com.baidatms.module.system.controller.admin.logininfoouter.vo.*;

/**
 * 外部物流商登录信息 Mapper
 *
 * @author nodal
 */
@Mapper
public interface LoginInfoOuterMapper extends BaseMapperX<LoginInfoOuterDO> {

    default PageResult<LoginInfoOuterDO> selectPage(LoginInfoOuterPageReqVO reqVO) {
        return selectPage(reqVO, new LambdaQueryWrapperX<LoginInfoOuterDO>()
                .likeIfPresent(LoginInfoOuterDO::getUserName, reqVO.getUserName())
                .eqIfPresent(LoginInfoOuterDO::getLogisticsCompanyId, reqVO.getLogisticsCompanyId())
                .eqIfPresent(LoginInfoOuterDO::getLogisticsNetworkId, reqVO.getLogisticsNetworkId())
                .betweenIfPresent(LoginInfoOuterDO::getCreateTime, reqVO.getCreateTime())
                .eqIfPresent(LoginInfoOuterDO::getStatus, reqVO.getStatus())
                .orderByDesc(LoginInfoOuterDO::getId));
    }

}