package com.baidatms.module.system.dal.dataobject.logininfoouter;

import lombok.*;
import java.util.*;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.*;
import com.baidatms.framework.mybatis.core.dataobject.BaseDO;

/**
 * 外部物流商登录信息 DO
 *
 * @author nodal
 */
@TableName("system_login_info_outer")
@KeySequence("system_login_info_outer_seq") // 用于 Oracle、PostgreSQL、Kingbase、DB2、H2 数据库的主键自增。如果是 MySQL 等数据库，可不写。
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginInfoOuterDO extends BaseDO {

    /**
     * 自增序列
     */
    @TableId
    private Long id;
    /**
     * 物流商分配账号
     */
    private String userName;
    /**
     * 物流商秘钥
     */
    private String password;
    /**
     * 物流服务商ID
     */
    private Long logisticsCompanyId;
    /**
     * 物流网点ID
     */
    private Long logisticsNetworkId;
    /**
     * 接口调用方式1：web连接器；2：接口
     */
    private String callTyp;
    /**
     * 有效标志1：有效；0：无效
     */
    private String status;

}