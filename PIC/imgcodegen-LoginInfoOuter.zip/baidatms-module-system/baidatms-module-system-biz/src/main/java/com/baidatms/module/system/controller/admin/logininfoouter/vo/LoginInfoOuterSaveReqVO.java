package com.baidatms.module.system.controller.admin.logininfoouter.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import java.util.*;
import jakarta.validation.constraints.*;

@Schema(description = "管理后台 - 外部物流商登录信息新增/修改 Request VO")
@Data
public class LoginInfoOuterSaveReqVO {

    @Schema(description = "物流商分配账号", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotEmpty(message = "物流商分配账号不能为空")
    private String userName;

    @Schema(description = "物流商秘钥")
    private String password;

    @Schema(description = "物流服务商ID", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotNull(message = "物流服务商ID不能为空")
    private Long logisticsCompanyId;

    @Schema(description = "物流网点ID", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotNull(message = "物流网点ID不能为空")
    private Long logisticsNetworkId;

    @Schema(description = "接口调用方式1：web连接器；2：接口", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotEmpty(message = "接口调用方式1：web连接器；2：接口不能为空")
    private String callTyp;

    @Schema(description = "有效标志1：有效；0：无效", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotEmpty(message = "有效标志1：有效；0：无效不能为空")
    private String status;

}