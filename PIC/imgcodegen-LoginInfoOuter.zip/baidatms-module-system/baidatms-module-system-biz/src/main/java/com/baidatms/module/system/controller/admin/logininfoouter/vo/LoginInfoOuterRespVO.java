package com.baidatms.module.system.controller.admin.logininfoouter.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import java.util.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDateTime;
import com.alibaba.excel.annotation.*;

@Schema(description = "管理后台 - 外部物流商登录信息 Response VO")
@Data
@ExcelIgnoreUnannotated
public class LoginInfoOuterRespVO {

    @Schema(description = "自增序列", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("自增序列")
    private Long id;

    @Schema(description = "物流商分配账号", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("物流商分配账号")
    private String userName;

    @Schema(description = "物流商秘钥")
    @ExcelProperty("物流商秘钥")
    private String password;

    @Schema(description = "物流服务商ID", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("物流服务商ID")
    private Long logisticsCompanyId;

    @Schema(description = "物流网点ID", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("物流网点ID")
    private Long logisticsNetworkId;

    @Schema(description = "接口调用方式1：web连接器；2：接口", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("接口调用方式1：web连接器；2：接口")
    private String callTyp;

    @Schema(description = "更新时间", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("更新时间")
    private LocalDateTime updateTime;

    @Schema(description = "有效标志1：有效；0：无效", requiredMode = Schema.RequiredMode.REQUIRED)
    @ExcelProperty("有效标志1：有效；0：无效")
    private String status;

}