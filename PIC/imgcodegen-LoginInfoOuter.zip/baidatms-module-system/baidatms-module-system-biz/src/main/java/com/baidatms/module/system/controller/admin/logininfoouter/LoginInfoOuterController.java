package com.baidatms.module.system.controller.admin.logininfoouter;

import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
import org.springframework.validation.annotation.Validated;
import org.springframework.security.access.prepost.PreAuthorize;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;

import jakarta.validation.constraints.*;
import jakarta.validation.*;
import jakarta.servlet.http.*;
import java.util.*;
import java.io.IOException;

import com.baidatms.framework.common.pojo.PageParam;
import com.baidatms.framework.common.pojo.PageResult;
import com.baidatms.framework.common.pojo.CommonResult;
import com.baidatms.framework.common.util.object.BeanUtils;
import static com.baidatms.framework.common.pojo.CommonResult.success;

import com.baidatms.framework.excel.core.util.ExcelUtils;

import com.baidatms.framework.apilog.core.annotation.ApiAccessLog;
import static com.baidatms.framework.apilog.core.enums.OperateTypeEnum.*;

import com.baidatms.module.system.controller.admin.logininfoouter.vo.*;
import com.baidatms.module.system.dal.dataobject.logininfoouter.LoginInfoOuterDO;
import com.baidatms.module.system.service.logininfoouter.LoginInfoOuterService;

@Tag(name = "管理后台 - 外部物流商登录信息")
@RestController
@RequestMapping("/system/login-info-outer")
@Validated
public class LoginInfoOuterController {

    @Resource
    private LoginInfoOuterService loginInfoOuterService;

    @PostMapping("/create")
    @Operation(summary = "创建外部物流商登录信息")
    @PreAuthorize("@ss.hasPermission('system:login-info-outer:create')")
    public CommonResult<Long> createLoginInfoOuter(@Valid @RequestBody LoginInfoOuterSaveReqVO createReqVO) {
        return success(loginInfoOuterService.createLoginInfoOuter(createReqVO));
    }

    @PutMapping("/update")
    @Operation(summary = "更新外部物流商登录信息")
    @PreAuthorize("@ss.hasPermission('system:login-info-outer:update')")
    public CommonResult<Boolean> updateLoginInfoOuter(@Valid @RequestBody LoginInfoOuterSaveReqVO updateReqVO) {
        loginInfoOuterService.updateLoginInfoOuter(updateReqVO);
        return success(true);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除外部物流商登录信息")
    @Parameter(name = "id", description = "编号", required = true)
    @PreAuthorize("@ss.hasPermission('system:login-info-outer:delete')")
    public CommonResult<Boolean> deleteLoginInfoOuter(@RequestParam("id") Long id) {
        loginInfoOuterService.deleteLoginInfoOuter(id);
        return success(true);
    }

    @GetMapping("/get")
    @Operation(summary = "获得外部物流商登录信息")
    @Parameter(name = "id", description = "编号", required = true, example = "1024")
    @PreAuthorize("@ss.hasPermission('system:login-info-outer:query')")
    public CommonResult<LoginInfoOuterRespVO> getLoginInfoOuter(@RequestParam("id") Long id) {
        LoginInfoOuterDO loginInfoOuter = loginInfoOuterService.getLoginInfoOuter(id);
        return success(BeanUtils.toBean(loginInfoOuter, LoginInfoOuterRespVO.class));
    }

    @GetMapping("/page")
    @Operation(summary = "获得外部物流商登录信息分页")
    @PreAuthorize("@ss.hasPermission('system:login-info-outer:query')")
    public CommonResult<PageResult<LoginInfoOuterRespVO>> getLoginInfoOuterPage(@Valid LoginInfoOuterPageReqVO pageReqVO) {
        PageResult<LoginInfoOuterDO> pageResult = loginInfoOuterService.getLoginInfoOuterPage(pageReqVO);
        return success(BeanUtils.toBean(pageResult, LoginInfoOuterRespVO.class));
    }

    @GetMapping("/export-excel")
    @Operation(summary = "导出外部物流商登录信息 Excel")
    @PreAuthorize("@ss.hasPermission('system:login-info-outer:export')")
    @ApiAccessLog(operateType = EXPORT)
    public void exportLoginInfoOuterExcel(@Valid LoginInfoOuterPageReqVO pageReqVO,
              HttpServletResponse response) throws IOException {
        pageReqVO.setPageSize(PageParam.PAGE_SIZE_NONE);
        List<LoginInfoOuterDO> list = loginInfoOuterService.getLoginInfoOuterPage(pageReqVO).getList();
        // 导出 Excel
        ExcelUtils.write(response, "外部物流商登录信息.xls", "数据", LoginInfoOuterRespVO.class,
                        BeanUtils.toBean(list, LoginInfoOuterRespVO.class));
    }

}