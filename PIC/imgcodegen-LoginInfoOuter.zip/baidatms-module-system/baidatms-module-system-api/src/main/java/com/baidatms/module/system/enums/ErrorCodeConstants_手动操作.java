// TODO 待办：请将下面的错误码复制到 baidatms-module-system-api 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 外部物流商登录信息 TODO 补充编号 ==========
ErrorCode LOGIN_INFO_OUTER_NOT_EXISTS = new ErrorCode(TODO 补充编号, "外部物流商登录信息不存在");